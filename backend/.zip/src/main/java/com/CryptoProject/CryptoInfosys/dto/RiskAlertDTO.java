package com.CryptoProject.CryptoInfosys.dto;

public class RiskAlertDTO {

    public String asset;
    public String symbol;
    public String riskLevel; // LOW / MEDIUM / HIGH
    public String reason;
}
