package com.CryptoProject.CryptoInfosys.model;

public enum TradeSide {
    BUY,
    SELL
}
