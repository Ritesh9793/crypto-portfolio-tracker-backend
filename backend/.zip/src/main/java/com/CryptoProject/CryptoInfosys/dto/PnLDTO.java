package com.CryptoProject.CryptoInfosys.dto;

public class PnLDTO {

    public String asset;
    public String symbol;

    public double quantity;
    public double avgBuyPrice;

    public double currentPrice;

    public double unrealizedPnL;
    public double realizedPnL;
}
