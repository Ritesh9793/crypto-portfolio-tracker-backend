package com.CryptoProject.CryptoInfosys.dto;

import java.time.LocalDate;

public class PnLTimelineDTO {

    public LocalDate date;
    public double cumulativePnL;
}
