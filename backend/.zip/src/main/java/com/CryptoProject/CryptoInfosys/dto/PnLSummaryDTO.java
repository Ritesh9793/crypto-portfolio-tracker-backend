package com.CryptoProject.CryptoInfosys.dto;

import java.util.List;

public class PnLSummaryDTO {

    public double totalUnrealizedPnL;
    public double totalRealizedPnL;

    public List<PnLDTO> assets;
}
